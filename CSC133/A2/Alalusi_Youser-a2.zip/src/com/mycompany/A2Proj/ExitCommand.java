package com.mycompany.A2Proj;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;

public class ExitCommand extends Command {
	
	public ExitCommand() {
		
		super("Exit");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(Dialog.show("Exit", "Do you want to exit the game?", "Yes", "No")) {
			System.exit(0);
		}
		
	}

}