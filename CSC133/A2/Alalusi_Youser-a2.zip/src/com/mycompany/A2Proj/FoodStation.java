package com.mycompany.A2Proj;

public class FoodStation extends FixedGameObject {
	
	private int capacity;
	private int size;
	
	public FoodStation() {
		
		setSize((25) + getRandom(5));
		setColor(255, 255, 0); //Yellow
		size = getSize();
		setCapacity(size);
		
	}
	

	/**
	 * Method to request capacity
	 * 
	 * @return capacity
	 */
	public int getCapacity() {
		
		return capacity;
	}
	/**
	 * Method to set capacity
	 * 
	 * @param cap
	 */
	public void setCapacity(int cap) {
		
		capacity = cap;
	}
	/**
	 * Method to override toString
	 */
	public String toString() {
		
		String supString = super.toString();
		String value = " size= " + getSize() + " capacity= " + capacity;
		
		String concValue = "FoodStation: " + supString + value;
		
		return concValue;
	}

}
