package com.mycompany.A2Proj;


public interface ISteerable {

	public void changeDirection(char c);

}
