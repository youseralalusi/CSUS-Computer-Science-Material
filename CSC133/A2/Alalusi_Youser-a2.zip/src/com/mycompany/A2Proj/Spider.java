package com.mycompany.A2Proj;

public class Spider extends MovableGameObject {

	public Spider() {
		
		setSize(20 + getRandom((10)));
		setColor(0, 0, 0); //Black

	}

	/**
	 * Method to override toString
	 */
	public String toString() {
		
		String supString = super.toString();
		String value = " size= " + getSize();
		
		String concValue = "Spider: " + supString + value;
		
		return concValue;
	}

}
