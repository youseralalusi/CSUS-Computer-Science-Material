package com.mycompany.A2Proj;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;

public class FlagCommand extends Command {
	
	private GameWorld gw;
	
	public FlagCommand(GameWorld gw) {
		
		super("Collide with Flag");
		this.gw = gw;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Command cOk = new Command("Ok");
		Command cCancel = new Command("Cancel");
		TextField myTF = new TextField();
		Command[] cmd = new Command[] {cOk, cCancel};
		
		Command c = Dialog.show("Enter Flag: ", myTF, cmd);
		if(c == cOk) {
			String sCommand = myTF.getText().toString();
			if(sCommand.length() != 0) 
				switch(sCommand.charAt(0)) {
				
				case '1' :
					gw.flagCollision(1);
					break;
					
				case '2' :
					gw.flagCollision(2);
					break;
					
				case '3' :
					gw.flagCollision(3);
					break;
					
				case'4' :
					gw.flagCollision(4);
					break;
					
				default :
					System.out.println("Invalid Input!");
					break;
				}
		}
		
		else {
			System.out.println("No flag chosen!");
		}
	
	}


}