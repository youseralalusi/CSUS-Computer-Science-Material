package com.mycompany.A2Proj;

public abstract class FixedGameObject extends GameObject{
	
	private static int objectNum;
	private int size;
	
	/**
	 * Method provide sequence number
	 * 
	 * @return objectNum
	 */
	public int getObjectNumber() {
		
		objectNum++;
		return objectNum;
	}
	
	public void setSize(int i) {
		
		size = i;
	}
	
	public int getSize() {
		
		return size;
	}

}