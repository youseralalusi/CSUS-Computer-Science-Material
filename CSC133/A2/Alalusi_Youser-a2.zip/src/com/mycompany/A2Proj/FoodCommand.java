package com.mycompany.A2Proj;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class FoodCommand extends Command {
	
	private GameWorld gw;
	
	public FoodCommand(GameWorld gw) {
		
		super("Collide with Food Station");
		this.gw = gw;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		gw.foodCollision();
		
	}

}
