package com.mycompany.A2Proj;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class AccelCommand extends Command {
	
	private GameWorld gw;
	
	public AccelCommand(GameWorld gw) {
		
		super("Accelerate");
		this.gw = gw;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		gw.changeSpeed('a');
		
	}

}
