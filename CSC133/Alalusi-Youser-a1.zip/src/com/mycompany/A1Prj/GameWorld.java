package com.mycompany.A1Prj;

import java.util.ArrayList;
import java.util.Random;

/**
 * @author Youser Alalusi
 *
 */
public class GameWorld {
	
	private int elapsedTime;
	private int antLives;
	private int numFlags;
	private int lastFlagReached;
	private Ant theAnt;
	Random random = new Random();

	public ArrayList<GameObject> gameObject = new ArrayList<GameObject>();
	
	public GameWorld() {
	}
	
	//Method to create initial state of world
	public void init() {
		
		antLives = 3;
		elapsedTime = 0;
		numFlags = 4;
		lastFlagReached = 1;
	
		//Creating objects of world
		createFoodStations();
		createFourFlags();
		createTwoSpiders();
		theAnt = createAnt();
		
	}
	
	//Creating Ant object
	public Ant createAnt() {
		
		Ant ant = new Ant();
		gameObject.add(ant);
		System.out.println("\nAnt has entered GameWorld!");
		return ant;

	}
	
	//Creating Spider object
	public void createTwoSpiders() {
		
		Spider spider1 = new Spider();
		Spider spider2 = new Spider();
		gameObject.add(spider1);
		gameObject.add(spider2);
	}
	
	//Create flags objects
	public void createFourFlags() {
		
		Flags flag1 = new Flags();
		flag1.setLocationX(200);
		flag1.setLocationY(900);
		gameObject.add(flag1);
		
		Flags flag2 = new Flags();
		flag2.setLocationX(500);
		flag2.setLocationY(100);
		gameObject.add(flag2);
		
		Flags flag3 = new Flags();
		flag3.setLocationX(900);
		flag3.setLocationY(400);
		gameObject.add(flag3);
		
		Flags flag4 = new Flags();
		flag4.setLocationX(100);
		flag4.setLocationY(700);
		gameObject.add(flag4);
	
	}
	
	//Create food stations
	public void createFoodStations() {
		
		FoodStation foodStation1 = new FoodStation();
		FoodStation foodStation2 = new FoodStation();
		
		gameObject.add(foodStation1);
		gameObject.add(foodStation2);
		
	}
	//Creating additional food stations
	public void addFoodStation() {
		
		FoodStation newStation = new FoodStation();
		gameObject.add(newStation);
	}
	//Returns current Ant lives
	public int getAntLives() {
		return antLives;
	}
	//Returns current Ant food level
	public int getFoodLevel() {
		
		return theAnt.getFoodLevel();
	}
	//Method call to change Ant speed
	public void changeSpeed(char c) {
		
		theAnt.changeSpeed(c);
			
	}
	//Method call to change Ant direction
	public void changeDirection(char c) {
		
		theAnt.changeDirection(c);
		
	}
	//Method to notify flag collision
	public void flagCollision(int x) {
		
		int flag = x;
		if( (flag == lastFlagReached + 1)) {
			setLastFlagReached(flag);
			System.out.println("\nYou have reached flag #" + flag);
			
		}
		else {
			System.out.println("\nYou can't jump to this flag!");
			
		}
		
	}
	//Method to update last flag reached
	public void setLastFlagReached(int x) {
		
		lastFlagReached = x;
	}
	//Method to request current flag
	public int getLastFlagReached() {
		
		return lastFlagReached;
	}
	//Method to notify food station collision
	public void foodCollision() {
		
		System.out.println("\nYou have reached a food station!");
		for(int i = 0; i < gameObject.size(); i++) {
			
			if(gameObject.get(i) instanceof FoodStation) {
				FoodStation station = (FoodStation) gameObject.get(i);
				if(station.getCapacity() != 0) {
					
					int foodLevelNew = station.getCapacity();
					theAnt.setFoodLevel(foodLevelNew);
					station.setCapacity(0);
					station.setColor(255, 255, 204);
					addFoodStation();
					break;
				}
			}
		}
		
	}
	//Method to notify spider collision
	public void spiderCollision() {
		
		System.out.println("\nYou have collided with a Spider!");
		for(int i = 0; i < gameObject.size(); i++) {
			if(gameObject.get(i) instanceof Spider) {
				if(theAnt.getHealthLevel() != 0) {
					theAnt.setHealthLevel(theAnt.getHealthLevel() - 1);
					System.out.println("Health: " + theAnt.getHealthLevel());
					theAnt.setColor(255, 102, 102);
					break;

				}
			}
		}
		
	}
	//Method to start clock and move objects
	public void clockTick() {
		
		for(int i = 0; i < gameObject.size(); i++) {
			
			if(gameObject.get(i) instanceof MovableGameObject) {
				
				((MovableGameObject) gameObject.get(i)).moveNew();
				if(gameObject.get(i) instanceof Spider) {
					
					Spider mObj = (Spider) gameObject.get(i);
					mObj.setDirection(random.nextInt(359));
					mObj.getDirection();
				}
				
			}
		}
		elapsedTime++;
		System.out.println("\nAnt and Spider are on the move!");
	}
	//Method for game display
	public void printGameDisplay() {
		
		System.out.println("\n*********** REAL TIME DISPLAY **************\n");
		System.out.println("Ant lives: " + getAntLives());
		System.out.println("Game Time: " + elapsedTime);
		System.out.println("Current flag: " + getLastFlagReached());
		System.out.println("Current Food Level: " + getFoodLevel());
		System.out.println("Current health level: " + theAnt.getHealthLevel());
		System.out.println("\n***********************************************");
		
	}
	//Method for game map
	public void printGameMap() {
		
		System.out.println("\n*************** GAME MAP *******************\n");
		for(int i = 0; i < gameObject.size(); i++) {
			System.out.println(gameObject.get(i));
		}
		System.out.println("\n***********************************************");

		
	}
	//Method to allow user exit game
	public void exitOnTargetGame() {
		
		System.out.println("\nThank you for playing!");
		System.exit(0);

	}

}
