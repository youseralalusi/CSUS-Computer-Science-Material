package com.mycompany.A1Prj;

public class Ant extends MovableGameObject implements ISteerable{
	
	private int maxSpeed;
	private int foodLevel;
	private int foodConsumptionRate;
	private int healthLevel;
	private int speed;
	private int direction;
	
	public Ant() {
		
		maxSpeed = 50;
		setHealthLevel(10);
		setSize(40);
		setColor(255, 0, 0); //Red
		foodConsumptionRate = 2;
		setSpeed(30);
		speed = getSpeed();
		setDirection(0);
		direction = getDirection();
		setFoodLevel(15);
	}
	
	public void resetLocation() {
		
		setLocationX(0);
		setLocationY(0);
	}
	
	/**
	 * Method to change Ant speed
	 * 
	 * @param c
	 */
	public void changeSpeed(char c) {
		
		switch(c) {
		
		case 'a' :
			if(speed >= 50) {
				speed = speed - 5;
				System.out.println("Ant can't go any faster!");
				break;
			}
			else
				speed = speed + 5;
				System.out.println("\nAnt has accelerated!");
				System.out.println("Speed of Ant is now: " + speed);
				setSpeed(speed);
				break;
				
		case 'b' :
			speed = speed - 5;
			System.out.println("\nAnt has slowed down!");
			System.out.println("Speed of Ant is now: " + speed);
			setSpeed(speed);
			break;
			
		default:
			break;
			
		}
	}
	//Method created to change heading of Ant
	
	/**
	 * @param c
	 */
	public void changeDirection(char c) {
		
		switch(c) {
		
		case 'r' :
			direction = direction - 5;
			System.out.println("\nAnt has turned right!");
			System.out.println("Heading of Ant is now: " + direction);
			setDirection(direction);
			break;
			
		case 'l' :
			direction = direction + 5;
			System.out.println("\nAnt has turned left!");
			System.out.println("Heading of Ant is now: " + direction);
			setDirection(direction);
			break;
		}
		
	}
	/**
	 * Method to request health
	 * 
	 * @return healthLevel
	 */
	public int getHealthLevel() {
		
		return healthLevel;
	}
	/**
	 * Method to set health
	 * 
	 * @param x
	 */
	public void setHealthLevel(int x) {
		
		healthLevel = x;
	}
	/**
	 * Method to request food level
	 * 
	 * @return foodLevel
	 */
	public int getFoodLevel() {
		
		return foodLevel;
	}
	/**
	 * Method to set food level
	 * 
	 * @param x
	 */
	public void setFoodLevel(int x) {
		
		foodLevel = x;
	}
	/**
	 * Method to override toString
	 */
	public String toString() {
		
		String supString = super.toString();
		String value = " size= " + getSize() + " maxSpeed= " + maxSpeed + 
				" foodConsumptionRate= " + foodConsumptionRate;
		
		String concValue = "Ant:    " + supString + value;
		
		return concValue;
	}

	@Override
	public void turnHeading() {
		// TODO Auto-generated method stub
		
	}

}
