package com.mycompany.A1Prj;

public class Spider extends MovableGameObject {
	
	private int speed;

	public Spider() {
		
		speed = getSpeed();
		setSize(20 + getRandom((10)));
		setColor(0, 0, 0); 

	}
	/**
	 * Method to override toString
	 */
	public String toString() {
		
		String supString = super.toString();
		String value = " size= " + getSize();
		
		String concValue = "Spider: " + supString + value;
		
		return concValue;
	}

}
