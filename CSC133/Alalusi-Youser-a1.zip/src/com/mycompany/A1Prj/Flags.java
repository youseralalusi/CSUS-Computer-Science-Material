package com.mycompany.A1Prj;

public class Flags extends FixedGameObject{
	
	private int flagNum;
	private int flagSize;

	public Flags() {
		
		flagNum = getObjectNumber();
		flagSize = 10;
		setColor(0, 204, 0); //Green
		
	}
	/**
	 * Method to override toString
	 */
	public String toString() {
		
		String supString = super.toString();
		String value = " size= " + flagSize + " seqNum= " + flagNum;
		
		String concValue = "Flag:   " + supString + value;
		
		return concValue;
	}

}
