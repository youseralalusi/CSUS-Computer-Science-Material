package com.mycompany.A1Prj;

public interface ISteerable {
	
	public void turnHeading();

}
