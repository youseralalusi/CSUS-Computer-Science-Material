package com.mycompany.A1Prj;

public abstract class FixedGameObject extends GameObject{
	
	private static int objectNum;
	
	/**
	 * Method provide sequence number
	 * 
	 * @return objectNum
	 */
	public int getObjectNumber() {
		
		objectNum++;
		return objectNum;
	}

}
