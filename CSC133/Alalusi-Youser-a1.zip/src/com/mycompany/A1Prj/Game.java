package com.mycompany.A1Prj;

import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;

public class Game extends Form {
	
	private GameWorld gw;

	
	public Game() {
		gw = new GameWorld();
		gw.init();
		play();
	}

	private void play() {
		
		Label myLabel = new Label("Enter a Command: ");
		this.add(myLabel);
		final TextField myTextField = new TextField();
		this.add(myTextField);
		this.show();
		
		myTextField.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent evt) {
				String sCommand = myTextField.getText().toString();
				myTextField.clear();
				if(sCommand.length() != 0)
					switch (sCommand.charAt(0)) {
					
					//Method call to accelerate the speed of Ant
					case 'a' :
						gw.changeSpeed('a');
						break;
					//Method call to slow down the speed of Ant
					case 'b' :
						gw.changeSpeed('b');
						break;
					//Method call to change heading of Ant
					case 'l' :
						gw.changeDirection('l');
						break;
					//Method call to change heading of Ant
					case 'r' :
						gw.changeDirection('r');
						break;
					//Method call to check flag collision
					case '1' :
						gw.flagCollision(1);
						break;
					case '2' :
						gw.flagCollision(2);
						break;
					case '3' :
						gw.flagCollision(3);
						break;
					case '4' :
						gw.flagCollision(4);
						break;
					//Method call to check food station collision
					case 'f' :
						gw.foodCollision();
						break;
					//Method call to check collision between Spider and Ant
					case 'g' :
						gw.spiderCollision();
						break;
					//Method to tick game clock
					case 't' :
						gw.clockTick();
						break;
					//Method to generate game display
					case 'd' :
						gw.printGameDisplay();
						break;
					//Method to print game map
					case 'm' :
						gw.printGameMap();
						break;
					//Method to exit game
					case 'x' :
						gw.exitOnTargetGame();
						break;
					default:
						System.out.println("Input is invalid!\n");
						break;
					
					} //switch
			} //actionPerformed
		} //new ActionListener()
		); //addActionListener

	} //play
}