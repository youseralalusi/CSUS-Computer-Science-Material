
import java.io.FileWriter;


/**
 * interface of 4 algorithm RR, SJF and PR_*
 * @author 12-45-5-9-2020
 */
public interface SchedulingMethod {
    public void run(FileWriter fileWriter);
}
